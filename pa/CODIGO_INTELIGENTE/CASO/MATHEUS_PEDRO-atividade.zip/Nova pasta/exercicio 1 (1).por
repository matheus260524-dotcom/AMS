programa {
  funcao inicio() {
    inteiro numero
    cadeia nome 


    escreva("digite nome :")
    leia(nome)

    escreva("digite numero : ")
    leia(numero)
    
    escolha(numero){
      caso 1:
        escreva("seu nome é: ",   nome , " Esta cursando: informática-vespertino")
      pare

  caso 2:
    escreva("seu nome é: ",   nome , " Esta cursando: informática-vespertino")
  pare

  caso 3:
  escreva("seu nome é: ",   nome , " Esta cursando: secretariado")
  pare

  caso 4:
  escreva("seu nome é: ",   nome , "  Esta cursando: administração")
  pare

  caso 5:
  escreva("seu nome é: ",   nome , " Esta cursando: logistica")
  pare



  
	caso contrario:
  escreva("erro 67")

  }
    

  }
}
